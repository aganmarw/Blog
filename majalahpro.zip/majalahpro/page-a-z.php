<?php
/**
 * Template Name: A-Z Pages
 *
 * A WordPress template to list page titles by first letter.
 *
 * You should modify the CSS to suit your theme and place it in its proper file.
 * Be sure to set the $posts_per_row and $posts_per_page variables.
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

?>

<div id="primary" class="content-area col-md-content">

	<?php do_action( 'majalahpro_core_view_breadcrumbs' ); ?>

	<main id="main" class="site-main" role="main">

	<?php

	if ( have_posts() ) {

		echo '<div class="gmr-box-content gmr-single">';

		echo '<header class="entry-header">';
			the_title( '<h1 class="title" ' . majalahpro_itemprop_schema( 'headline' ) . '>', '</h1>' );
			echo '<div class="screen-reader-text">';
				gmr_posted_on();
			echo '</div>';
		echo '</header><!-- .entry-header -->';

		$arg = array(
			'post_type' => array( 'post' ),
		);

		$categories = get_categories( $arg );

		/* Start the Loop */
		foreach ( $categories as $cat ) {

			echo '<div class="gmr-az-list">';

				$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

				// get term by id custom taxonomy.
				$cat_id = $cat->term_id;

					echo '<div class="az-list-header">';

					echo '<h2><a href="' . esc_url( get_category_link( $cat->term_id ) ) . '" title="' . esc_html( $cat->name ) . '">' . esc_html( $cat->name ) . '</a> <span class="gmr-litle-title pull-right">' . intval( $cat->count ) . ' ' . esc_html__( 'news', 'majalahpro' ) . '</span></h2>';

					echo '</div>';

					// create a custom WordPress query.
					query_posts(
						array(
							'post_type'      => array( 'post' ),
							'post_status'    => 'publish',
							'cat'            => $cat_id,
							'posts_per_page' => 5,
							'paged'          => $paged,
						)
					);

					echo '<ul>';
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				?>
				<li>
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php esc_html_e( 'Permanent Link to', 'majalahpro' ); ?> <?php the_title_attribute(); ?>"><?php the_title(); ?></a>
				</li>
				<?php
			endwhile;
					echo '</ul>';

				echo '</div>';

		}

		echo '</div>';

	} else {
		echo '<h2>' . esc_html__( 'Sorry, no posts were found!', 'majalahpro' ) . '</h2>';
	}
	?>
	</main><!-- #main -->
</div><!-- #primary -->

<aside id="secondary" class="widget-area col-md-sb-r" role="complementary" <?php majalahpro_itemtype_schema( 'WPSideBar' ); ?>>
	<div class="widget majalahpro-tag-cloud">
	<h3 class="widget-title"><span><?php esc_html_e( 'Category', 'majalahpro' ); ?></span></h3>
	<?php
	echo '<div class="tagcloud">';
	echo '<ul class="wp-tag-cloud">';
	wp_list_categories(
		array(
			'title_li' => '',
		)
	);
	echo '</ul>';
	echo '</div>';
	?>
	</div>
	<div id="colophon" class="site-footer widget" role="contentinfo" <?php majalahpro_itemtype_schema( 'WPFooter' ); ?>>
		<?php
		$copyright = get_theme_mod( 'gmr_copyright' );
		if ( $copyright ) :
			// sanitize html output than convert it again using htmlspecialchars_decode.
			echo '<span class="pull-left theme-copyright">';
				echo esc_html( htmlspecialchars_decode( $copyright ) );
			echo '</span>';
		else :
			?>
			<a href="<?php echo esc_url( __( 'http://www.gianmr.com/', 'majalahpro' ) ); ?>" class="theme-copyright pull-left" title="<?php echo esc_html__( 'Theme: Majalahpro', 'majalahpro' ); ?>"><?php echo esc_html__( '&copy; Majalahpro', 'majalahpro' ); ?></a>
		<?php endif; ?>
		<?php
		// Second top menu.
		if ( has_nav_menu( 'copyrightnav' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'copyrightnav',
					'container'      => 'ul',
					'menu_id'        => 'copyright-menu',
					'depth'          => 1,
				)
			);
		}
		?>
	</div><!-- #colophon -->
</aside><!-- #secondary -->

<?php

get_footer();
