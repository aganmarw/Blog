<?php
/**
 * Widget API: Majalahpro_Module_Posts_Widget class
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @package Majalahpro
 * @subpackage Widgets
 * @since 1.0.0
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the Module Posts widget.
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class Majalahpro_Module_Posts_Widget extends WP_Widget {
	/**
	 * Sets up a Recent Posts widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'   => 'majalahpro-posts-module',
			'description' => __( 'Module posts for module home.', 'majalahpro' ),
		);
		parent::__construct( 'majalahpro-posts', __( 'Module Posts (Majalahpro)', 'majalahpro' ), $widget_ops );

		// add action for admin_register_scripts.
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_register_scripts' ) );
		add_action( 'admin_footer-widgets.php', array( $this, 'add_script_config' ) );
	}

	/**
	 * Add script to admin page
	 */
	public function admin_register_scripts() {
		// Build in tag auto complete script.
		wp_enqueue_script( 'suggest' );
	}

	/**
	 * Add script to admin page
	 */
	public function add_script_config() {
		?>
		<script type="text/javascript" >
		// Function to add auto suggest.
		function setSuggest(id) {
			jQuery('#' + id).suggest("<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>?action=ajax-tag-search&tax=post_tag", {multiple:true, multipleSep: ","});
		}
		function setSuggest_cat(id) {
			jQuery('#' + id).suggest("<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>?action=ajax-tag-search&tax=category", {multiple:true, multipleSep: ","});
		}
		</script>
		<?php
	}

	/**
	 * Outputs the content for Module Post.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for Mailchimp Form.
	 */
	public function widget( $args, $instance ) {

		global $post;
		// Title.
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		}
		// Base Id Widget.
		$majpro_widget_id = $this->id_base . '-' . $this->number;

		// Category ID.
		$majpro_category = ( ! empty( $instance['majpro_category'] ) ) ? wp_strip_all_tags( $instance['majpro_category'] ) : '';

		// Tag ID.
		$majpro_tag = ( ! empty( $instance['majpro_tag'] ) ) ? wp_strip_all_tags( $instance['majpro_tag'] ) : '';

		// Number Column.
		$majpro_column = ( ! empty( $instance['majpro_column'] ) ) ? wp_strip_all_tags( $instance['majpro_column'] ) : wp_strip_all_tags( 'modulecol2' );

		// Excerpt Length.
		$majpro_number_posts = ( ! empty( $instance['majpro_number_posts'] ) ) ? absint( $instance['majpro_number_posts'] ) : absint( 8 );

		// Title Length.
		$majpro_title_length = ( ! empty( $instance['majpro_title_length'] ) ) ? absint( $instance['majpro_title_length'] ) : absint( 100 );

		// standard params.
		$query_args = array(
			'posts_per_page'         => $majpro_number_posts,
			'no_found_rows'          => true,
			'post_status'            => 'publish',
			// make it fast withour update term cache and cache results
			// https://thomasgriffin.io/optimize-wordpress-queries/.
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'cache_results'          => false,
		);

		$query_args['ignore_sticky_posts'] = true;

		// set order of posts in widget.
		$query_args['orderby'] = 'date';
		$query_args['order']   = 'DESC';

		// add categories param only if 'all categories' was not selected.
		$cat_id_array = $this->generate_cat_id_from_name( $majpro_category );
		if ( count( $cat_id_array ) > 0 ) {
			$query_args['category__in'] = $cat_id_array;
		}

		// add tags param only if 'all tags' was not selected.
		$tag_id_array = $this->generate_tag_id_from_name( $majpro_tag );
		if ( count( $tag_id_array ) > 0 ) {
			$query_args['tag__in'] = $tag_id_array;
		}

		// run the query: get the latest posts.
		$rp = new WP_Query( apply_filters( 'majpro_rp_widget_posts_args', $query_args ) );

		if ( $rp->have_posts() ) :
			?>
			<div class="gmr-module-posts <?php echo esc_html( $majpro_column ); ?>">
				<ul>
					<?php
					while ( $rp->have_posts() ) :
						$rp->the_post();
						?>
						<li>
							<div class="gmr-module-item">
							<?php
							// Add thumnail.
							if ( has_post_thumbnail() ) :
								echo '<div class="widget-content-thumbnail">';
									echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="' .
									the_title_attribute(
										array(
											'before' => __( 'Permalink to: ', 'majalahpro' ),
											'after'  => '',
											'echo'   => false,
										)
									) . '" rel="bookmark">';
										the_post_thumbnail( 'large' );
								if ( has_post_format( 'gallery' ) ) {
									echo '<span class="icon_image"></span>';

								} elseif ( has_post_format( 'video' ) ) {
									echo '<span class="arrow_triangle-right"></span>';

								}
									echo '</a>';
								echo '</div>';

							endif;
							echo '<div class="widget-content-thumbnail">';
								echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="' .
								the_title_attribute(
									array(
										'before' => __( 'Permalink to: ', 'majalahpro' ),
										'after'  => '',
										'echo'   => false,
									)
								) . '" rel="bookmark">';
							if ( $post_title = $this->get_the_trimmed_post_title( $majpro_title_length ) ) {
								echo esc_html( $post_title );
							} else {
								the_title();
							}
								echo '</a>';
							echo '</div>';
							?>
						</li>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>
			<?php
		endif; // endif rp have_posts().

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Handles updating settings for the current Mailchimp widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            Majalahpro_Module_Posts_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance     = $old_instance;
		$new_instance = wp_parse_args(
			(array) $new_instance,
			array(
				'title'               => '',
				'majpro_category'     => '',
				'majpro_tag'          => '',
				'majpro_column'       => 'modulecol2',
				'majpro_number_posts' => 8,
				'majpro_title_length' => 100,
			)
		);
		// Title.
		$instance['title'] = sanitize_text_field( $new_instance['title'] );

		// Category IDs.
		$instance['majpro_category'] = wp_strip_all_tags( $new_instance['majpro_category'] );

		// Tag IDs.
		$instance['majpro_tag'] = wp_strip_all_tags( $new_instance['majpro_tag'] );

		// Column.
		$instance['majpro_column'] = wp_strip_all_tags( $new_instance['majpro_column'] );

		// Number posts.
		$instance['majpro_number_posts'] = absint( $new_instance['majpro_number_posts'] );

		// Title Length.
		$instance['majpro_title_length'] = absint( $new_instance['majpro_title_length'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Mailchimp widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'               => 'Recent Post',
				'majpro_category'     => '',
				'majpro_tag'          => '',
				'majpro_column'       => 'modulecol2',
				'majpro_number_posts' => 8,
				'majpro_title_length' => 100,
			)
		);
		// Title.
		$title = sanitize_text_field( $instance['title'] );

		// Category ID.
		$majpro_category = wp_strip_all_tags( $instance['majpro_category'] );

		// Tag ID.
		$majpro_tag = wp_strip_all_tags( $instance['majpro_tag'] );

		// Column.
		$majpro_column = wp_strip_all_tags( $instance['majpro_column'] );

		// Number posts.
		$majpro_number_posts = absint( $instance['majpro_number_posts'] );

		// Title Length.
		$majpro_title_length = absint( $instance['majpro_title_length'] );

		?>

		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'majalahpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'majpro_category' ) ); ?>"><?php esc_html_e( 'Selected categories', 'majalahpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'majpro_category' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'majpro_category' ) ); ?>" type="text" value="<?php echo esc_html( $majpro_category ); ?>" onfocus ="setSuggest_cat('<?php echo esc_html( $this->get_field_id( 'majpro_category' ) ); ?>');" />
			<br />
			<small><?php esc_html_e( 'Category Names, separated by commas. Eg: News, Home Design, Technology.', 'majalahpro' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'majpro_tag' ) ); ?>"><?php esc_html_e( 'Selected tags', 'majalahpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'majpro_tag' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'majpro_tag' ) ); ?>" type="text" value="<?php echo esc_html( $majpro_tag ); ?>" onfocus ="setSuggest('<?php echo esc_html( $this->get_field_id( 'majpro_tag' ) ); ?>');" />
			<br />
			<small><?php esc_html_e( 'Tag Names, separated by commas. Eg: Name Tag 1,Name Tag 2, Other Name Tag.', 'majalahpro' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'majpro_column' ) ); ?>"><?php esc_html_e( 'Column', 'majalahpro' ); ?></label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'majpro_column' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'majpro_column' ) ); ?>">
				<option value="modulecol2" <?php echo selected( $instance['majpro_column'], 'modulecol2', false ); ?>><?php esc_html_e( '2 Column', 'majalahpro' ); ?></option>
				<option value="modulecol3" <?php echo selected( $instance['majpro_column'], 'modulecol3', false ); ?>><?php esc_html_e( '3 Column', 'majalahpro' ); ?></option>
				<option value="modulecol4" <?php echo selected( $instance['majpro_column'], 'modulecol4', false ); ?>><?php esc_html_e( '4 Column', 'majalahpro' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'majpro_number_posts' ) ); ?>"><?php esc_html_e( 'Number post', 'majalahpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'majpro_number_posts' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'majpro_number_posts' ) ); ?>" type="number" value="<?php echo esc_attr( $majpro_number_posts ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'majpro_title_length' ) ); ?>"><?php esc_html_e( 'Maximum length of title', 'majalahpro' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'majpro_title_length' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'majpro_title_length' ) ); ?>" type="number" value="<?php echo esc_attr( $majpro_title_length ); ?>" />
		</p>
		<?php
	}

	/**
	 * Return the array index of a given ID
	 *
	 * @since 1.0.0
	 * @param array $arr Array.
	 * @param int   $id Post ID.
	 * @access private
	 */
	private function get_parent_index( $arr, $id ) {
		$len = count( $arr );
		if ( 0 === $len ) {
			return false;
		}
		$id = absint( $id );
		for ( $i = 0; $i < $len; $i++ ) {
			if ( $id === $arr[ $i ]['id'] ) {
				return $i;
			}
		}
		return false;
	}

	/**
	 * Returns the shortened post title, must use in a loop.
	 *
	 * @since 1.0.0
	 * @param int    $len Number text to display.
	 * @param string $more Text Button.
	 * @return string.
	 */
	private function get_the_trimmed_post_title( $len = 40, $more = '&hellip;' ) {

		// get current post's post_title.
		$post_title = get_the_title();

		// if post_title is longer than desired.
		if ( mb_strlen( $post_title ) > $len ) {
			// get post_title in desired length.
			$post_title = mb_substr( $post_title, 0, $len );
			// append ellipses.
			$post_title .= $more;
		}
		// return text.
		return $post_title;
	}

	/**
	 * Generate Tag id from Tag name
	 *
	 * @param String $tags Tag Name.
	 * @since 1.0.1
	 * @static
	 * @access public
	 *
	 * @return array List of tag ids
	 */
	private function generate_tag_id_from_name( $tags ) {
		global $post;

		$tag_id_array = array();

		if ( ! empty( $tags ) ) {
			$tag_array = explode( ',', $tags );

			foreach ( $tag_array as $tag ) {
				$tag_id_array[] = $this->get_tag_ID( trim( $tag ) );
			}
		}

		return $tag_id_array;
	}

	/**
	 * Generate Cat id from Cat name
	 *
	 * @param String $cats Cat Name.
	 * @since 1.0.1
	 * @static
	 * @access public
	 *
	 * @return array List of cat ids
	 */
	private function generate_cat_id_from_name( $cats ) {
		global $post;

		$cat_id_array = array();

		if ( ! empty( $cats ) ) {
			$cat_array = explode( ',', $cats );

			foreach ( $cat_array as $cat ) {
				$cat_id_array[] = $this->get_cat_ID( trim( $cat ) );
			}
		}

		return $cat_id_array;
	}

	/**
	 * Get tag id from tag name or slug
	 *
	 * @since 1.0.1
	 * @static
	 * @access public
	 *
	 * @param string $tag_name Tag name or slug.
	 * @return int Term id. 0 if not found
	 */
	private function get_tag_ID( $tag_name ) {
		// Try tag name first.
		$tag = get_term_by( 'name', $tag_name, 'post_tag' );
		if ( $tag ) {
			return $tag->term_id;
		} else {
			// if Tag name is not found, try tag slug.
			$tag = get_term_by( 'slug', $tag_name, 'post_tag' );
			if ( $tag ) {
				return $tag->term_id;
			}
			return 0;
		}
	}

	/**
	 * Get cat id from cat name or slug
	 *
	 * @since 1.0.1
	 * @static
	 * @access public
	 *
	 * @param string $cat_name cat name or slug.
	 * @return int Term id. 0 if not found
	 */
	private function get_Cat_ID( $cat_name ) {
		// Try cat name first.
		$cat = get_term_by( 'name', $cat_name, 'category' );
		if ( $cat ) {
			return $cat->term_id;
		} else {
			// if cat name is not found, try cat slug.
			$cat = get_term_by( 'slug', $cat_name, 'category' );
			if ( $cat ) {
				return $cat->term_id;
			}
			return 0;
		}
	}

}

add_action(
	'widgets_init',
	function() {
		register_widget( 'Majalahpro_Module_Posts_Widget' );
	}
);
