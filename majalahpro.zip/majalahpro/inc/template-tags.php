<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_posted_on() {
		$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'majalahpro' ) );
		$posted_in       = '';
		if ( $categories_list ) {
			$posted_in = '<span class="cat-links">' . $categories_list . '</span>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = $time_string;

		$filter_title = str_replace( ' ', '%20', get_the_title() );

		$posted_by = sprintf(
			esc_html__( 'by %s', 'majalahpro' ),
			'<span class="entry-author vcard screen-reader-text" ' . majalahpro_itemprop_schema( 'author' ) . ' ' . majalahpro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'majalahpro' ) . esc_html( get_the_author() ) . '" ' . majalahpro_itemprop_schema( 'url' ) . '><span ' . majalahpro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>'
		);
		if ( is_single() ) {
			echo '<div class="gmr-metacontent">';
			echo '<span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<span class="screen-reader-text">' . $posted_by . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( function_exists( 'the_views' ) ) {
				echo '<span class="meta-separator">-</span><span class="view-single">';
					the_views();
				echo '</span>';
			}
			echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {

			echo '<div class="gmr-metacontent">' . $posted_in . '<span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span><span class="screen-reader-text">' . $posted_by . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			// Disable share options via customizer.
			$share_opsi = get_theme_mod( 'gmr_active-sharearchive', 0 );

			if ( 0 === $share_opsi ) :
				echo '<a href="https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( esc_url( get_permalink() ) ) . '" rel="nofollow" title="' . esc_html__( 'Share this', 'majalahpro' ) . '">';
				echo '<span class="gmr-archive-share gmr-archive-facebook"><span class="social_facebook"></span> ' . esc_html__( 'Share', 'majalahpro' ) . '</span>';
				echo '</a>';
				echo '<a href="https://twitter.com/share?url=' . rawurlencode( esc_url( get_permalink() ) ) . '&amp;text=' . esc_html( $filter_title ) . '" rel="nofollow" title="' . esc_html__( 'Tweet this', 'majalahpro' ) . '">';
				echo '<span class="gmr-archive-share gmr-archive-twitter"><span class="social_twitter"></span> ' . esc_html__( 'Tweet', 'majalahpro' ) . '</span>';
				echo '</a>';
			endif;

			echo '</div>';
		}
	}
endif; // endif gmr_posted_on.

if ( ! function_exists( 'gmr_posted_on_author_single' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_posted_on_author_single() {
		$posted_by = sprintf(
			esc_html__( 'by %s', 'majalahpro' ),
			'<span class="entry-author vcard" ' . majalahpro_itemprop_schema( 'author' ) . ' ' . majalahpro_itemtype_schema( 'person' ) . '><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . __( 'Permalink to: ', 'majalahpro' ) . esc_html( get_the_author() ) . '" ' . majalahpro_itemprop_schema( 'url' ) . '><span ' . majalahpro_itemprop_schema( 'name' ) . '>' . esc_html( get_the_author() ) . '</span></a></span>'
		);
		if ( is_single() ) {
			echo '<div class="gmr-metacontent"><span class="posted-on">' . $posted_by . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		}
	}
endif; // endif gmr_posted_on_author_single.
add_action( 'gmr_posted_on_author_single', 'gmr_posted_on_author_single', 40 );

if ( ! function_exists( 'gmr_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_entry_footer() {
		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() ) {

			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '<span class="icon_tags"></span>', ' ' );
			if ( $tags_list ) {
				printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'majalahpro' ) . '</span>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		edit_post_link(
			sprintf(
				/* translators: %s: Name of current post */
				esc_html__( 'Edit %s', 'majalahpro' ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
endif; // endif gmr_entry_footer.

if ( ! function_exists( 'gmr_footer_social' ) ) :
	/**
	 * This function add social icon in single footer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function gmr_footer_social() {

		// Option remove search button.
		$setting    = 'gmr_active-footersocial';
		$mod_social = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Social settings.
		$fb_url          = get_theme_mod( 'gmr_fb_url_icon' );
		$twitter_url     = get_theme_mod( 'gmr_twitter_url_icon' );
		$pinterest_url   = get_theme_mod( 'gmr_pinterest_url_icon' );
		$tumblr_url      = get_theme_mod( 'gmr_tumblr_url_icon' );
		$stumbleupon_url = get_theme_mod( 'gmr_stumbleupon_url_icon' );
		$wordpress_url   = get_theme_mod( 'gmr_wordpress_url_icon' );
		$instagram_url   = get_theme_mod( 'gmr_instagram_url_icon' );
		$dribbble_url    = get_theme_mod( 'gmr_dribbble_url_icon' );
		$vimeo_url       = get_theme_mod( 'gmr_vimeo_url_icon' );
		$linkedin_url    = get_theme_mod( 'gmr_linkedin_url_icon' );
		$deviantart_url  = get_theme_mod( 'gmr_deviantart_url_icon' );
		$skype_url       = get_theme_mod( 'gmr_skype_url_icon' );
		$youtube_url     = get_theme_mod( 'gmr_youtube_url_icon' );
		$myspace_url     = get_theme_mod( 'gmr_myspace_url_icon' );
		$picassa_url     = get_theme_mod( 'gmr_picassa_url_icon' );
		$flickr_url      = get_theme_mod( 'gmr_flickr_url_icon' );
		$blogger_url     = get_theme_mod( 'gmr_blogger_url_icon' );
		$spotify_url     = get_theme_mod( 'gmr_spotify_url_icon' );
		$rssicon         = get_theme_mod( 'gmr_active-rssicon', 0 );

		if ( $fb_url || $twitter_url || $pinterest_url || $tumblr_url || $stumbleupon_url || $wordpress_url || $instagram_url || $dribbble_url || $vimeo_url ||
		$linkedin_url || $deviantart_url || $skype_url || $youtube_url || $myspace_url || $picassa_url || $flickr_url || $blogger_url || $spotify_url || 0 === $rssicon ) :
			if ( 0 === $mod_social ) :
				echo '<ul class="footer-social-icon">';
				echo '<li class="social-text">' . esc_html__( 'Follow Us On', 'majalahpro' ) . '</li>';
				if ( $fb_url ) :
					echo '<li class="facebook"><a href="' . esc_url( $fb_url ) . '" title="' . esc_html__( 'Facebook', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_facebook"></span></a></li>';
				endif;

				if ( $twitter_url ) :
					echo '<li class="twitter"><a href="' . esc_url( $twitter_url ) . '" title="' . esc_html__( 'Twitter', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_twitter"></span></a></li>';
				endif;

				if ( $pinterest_url ) :
					echo '<li class="pinterest"><a href="' . esc_url( $pinterest_url ) . '" title="' . esc_html__( 'Pinterest', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_pinterest"></span></a></li>';
				endif;

				if ( $tumblr_url ) :
					echo '<li class="tumblr"><a href="' . esc_url( $tumblr_url ) . '" title="' . esc_html__( 'Tumblr', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_tumblr"></span></a></li>';
				endif;

				if ( $stumbleupon_url ) :
					echo '<li class="stumbleupon"><a href="' . esc_url( $stumbleupon_url ) . '" title="' . esc_html__( 'Stumbleupon', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_tumbleupon"></span></a></li>';
				endif;

				if ( $wordpress_url ) :
					echo '<li class="wordpress"><a href="' . esc_url( $wordpress_url ) . '" title="' . esc_html__( 'WordPress', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_wordpress"></span></a></li>';
				endif;

				if ( $instagram_url ) :
					echo '<li class="instagram"><a href="' . esc_url( $instagram_url ) . '" title="' . esc_html__( 'Instagram', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_instagram"></span></a></li>';
				endif;

				if ( $dribbble_url ) :
					echo '<li class="dribble"><a href="' . esc_url( $dribbble_url ) . '" title="' . esc_html__( 'Dribbble', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_dribbble"></span></a></li>';
				endif;

				if ( $vimeo_url ) :
					echo '<li class="vimeo"><a href="' . esc_url( $vimeo_url ) . '" title="' . esc_html__( 'Vimeo', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_vimeo"></span></a></li>';
				endif;

				if ( $linkedin_url ) :
					echo '<li class="linkedin"><a href="' . esc_url( $linkedin_url ) . '" title="' . esc_html__( 'Linkedin', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_linkedin"></span></a></li>';
				endif;

				if ( $deviantart_url ) :
					echo '<li class="devianart"><a href="' . esc_url( $deviantart_url ) . '" title="' . esc_html__( 'Deviantart', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_deviantart"></span></a></li>';
				endif;

				if ( $myspace_url ) :
					echo '<li class="myspace"><a href="' . esc_url( $myspace_url ) . '" title="' . esc_html__( 'Myspace', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_myspace"></span></a></li>';
				endif;

				if ( $skype_url ) :
					echo '<li class="skype"><a href="' . esc_url( $skype_url ) . '" title="' . esc_html__( 'Skype', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_skype"></span></a></li>';
				endif;

				if ( $youtube_url ) :
					echo '<li class="youtube"><a href="' . esc_url( $youtube_url ) . '" title="' . esc_html__( 'Youtube', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_youtube"></span></a></li>';
				endif;

				if ( $picassa_url ) :
					echo '<li class="picassa"><a href="' . esc_url( $picassa_url ) . '" title="' . esc_html__( 'Picassa', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_picassa"></span></a></li>';
				endif;

				if ( $flickr_url ) :
					echo '<li class="flickr"><a href="' . esc_url( $flickr_url ) . '" title="' . esc_html__( 'Flickr', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_flickr"></span></a></li>';
				endif;

				if ( $blogger_url ) :
					echo '<li class="blogger"><a href="' . esc_url( $blogger_url ) . '" title="' . esc_html__( 'Blogger', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_blogger"></span></a></li>';
				endif;

				if ( $spotify_url ) :
					echo '<li class="spotify"><a href="' . esc_url( $spotify_url ) . '" title="' . esc_html__( 'Spotify', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_spotify"></span></a></li>';
				endif;

				$delicious_url = get_theme_mod( 'gmr_delicious_url_icon' );
				if ( $delicious_url ) :
					echo '<li class="delicious"><a href="' . esc_url( $delicious_url ) . '" title="' . esc_html__( 'Delicious', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_delicious"></span></a></li>';
				endif;

				if ( 0 === $rssicon ) :
					echo '<li class="rssicon"><a href="' . esc_url( get_bloginfo( 'rss2_url' ) ) . '" title="' . esc_html__( 'RSS', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_rss"></span></a></li>';
				endif;

				echo '</ul>';
			endif;
		endif;
	}
endif; // endif gmr_footer_social.
add_filter( 'gmr_footer_social', 'gmr_footer_social', 15, 2 );

if ( ! function_exists( 'gmr_categorized_blog' ) ) :
	/**
	 * Returns true if a blog has more than 1 category.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	function gmr_categorized_blog() {
		if ( false === ( $all_the_cool_cats = get_transient( 'majalahpro_categories' ) ) ) {
			// Create an array of all the categories that are attached to posts.
			$all_the_cool_cats = get_categories(
				array(
					'fields'     => 'ids',
					'hide_empty' => 1,
					// We only need to know if there is more than one category.
					'number'     => 2,
				)
			);

			// Count the number of categories that are attached to the posts.
			$all_the_cool_cats = count( $all_the_cool_cats );

			set_transient( 'majalahpro_categories', $all_the_cool_cats );
		}

		if ( $all_the_cool_cats > 1 ) {
			// This blog has more than 1 category so gmr_categorized_blog should return true.
			return true;
		} else {
			// This blog has only 1 category so gmr_categorized_blog should return false.
			return false;
		}
	}
endif; // endif gmr_categorized_blog.

if ( ! function_exists( 'gmr_category_transient_flusher' ) ) :
	/**
	 * Flush out the transients used in gmr_categorized_blog.
	 *
	 * @since 1.0.0
	 */
	function gmr_category_transient_flusher() {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		// Like, beat it. Dig?
		delete_transient( 'majalahpro_categories' );
	}
endif; // endif gmr_category_transient_flusher.
add_action( 'edit_category', 'gmr_category_transient_flusher' );
add_action( 'save_post', 'gmr_category_transient_flusher' );

if ( ! function_exists( 'gmr_custom_excerpt_length' ) ) :
	/**
	 * Filter the except length to 22 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param int $length Excerpt length.
	 * @return int (Maybe) modified excerpt length.
	 */
	function gmr_custom_excerpt_length( $length ) {
		$length = get_theme_mod( 'gmr_excerpt_number', '22' );
		// absint sanitize int non minus.
		return absint( $length );
	}
endif; // endif gmr_custom_excerpt_length.
add_filter( 'excerpt_length', 'gmr_custom_excerpt_length', 999 );

if ( ! function_exists( 'gmr_custom_readmore' ) ) :
	/**
	 * Filter the except length to 20 characters.
	 *
	 * @since 1.0.0
	 *
	 * @param string $more More Text.
	 * @return string read more.
	 */
	function gmr_custom_readmore( $more ) {
		$more = get_theme_mod( 'gmr_read_more' );
		if ( empty( $more ) ) {
			return '';
		} else {
			return ' <a class="read-more" href="' . get_permalink( get_the_ID() ) . '" title="' . get_the_title( get_the_ID() ) . '" ' . majalahpro_itemprop_schema( 'url' ) . '>' . esc_html( $more ) . '</a>';
		}
	}
endif; // endif gmr_custom_readmore.
add_filter( 'excerpt_more', 'gmr_custom_readmore' );

if ( ! function_exists( 'gmr_get_pagination' ) ) :
	/**
	 * Retrieve paginated link for archive post pages.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	function gmr_get_pagination() {
		global $wp_rewrite;
		global $wp_query;
		return paginate_links(
			apply_filters(
				'gmr_get_pagination_args',
				array(
					'base'      => str_replace( '99999', '%#%', esc_url( get_pagenum_link( 99999 ) ) ),
					'format'    => $wp_rewrite->using_permalinks() ? 'page/%#%' : '?paged=%#%',
					'current'   => max( 1, get_query_var( 'paged' ) ),
					'total'     => $wp_query->max_num_pages,
					'prev_text' => __( 'Prev', 'majalahpro' ),
					'next_text' => __( 'Next', 'majalahpro' ),
					'type'      => 'list',
					'end_size'  => 0,
					'mid_size'  => 1,
				)
			)
		);
	}
endif; // endif gmr_get_pagination.

if ( ! function_exists( 'gmr_nav_wrap' ) ) :
	/**
	 * This function add search button in menu.
	 *
	 * @since 1.0.0
	 *
	 * @param string $items Item.
	 * @param array  $args Args.
	 * @param bool   $ajax default false.
	 * @return string
	 */
	function gmr_nav_wrap( $items, $args, $ajax = false ) {

		// Option remove search button.
		$setting    = 'gmr_active-topnavsocial';
		$mod_social = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Social settings.
		$fb_url          = get_theme_mod( 'gmr_fb_url_icon' );
		$twitter_url     = get_theme_mod( 'gmr_twitter_url_icon' );
		$pinterest_url   = get_theme_mod( 'gmr_pinterest_url_icon' );
		$tumblr_url      = get_theme_mod( 'gmr_tumblr_url_icon' );
		$stumbleupon_url = get_theme_mod( 'gmr_stumbleupon_url_icon' );
		$wordpress_url   = get_theme_mod( 'gmr_wordpress_url_icon' );
		$instagram_url   = get_theme_mod( 'gmr_instagram_url_icon' );
		$dribbble_url    = get_theme_mod( 'gmr_dribbble_url_icon' );
		$vimeo_url       = get_theme_mod( 'gmr_vimeo_url_icon' );
		$linkedin_url    = get_theme_mod( 'gmr_linkedin_url_icon' );
		$deviantart_url  = get_theme_mod( 'gmr_deviantart_url_icon' );
		$skype_url       = get_theme_mod( 'gmr_skype_url_icon' );
		$youtube_url     = get_theme_mod( 'gmr_youtube_url_icon' );
		$myspace_url     = get_theme_mod( 'gmr_myspace_url_icon' );
		$picassa_url     = get_theme_mod( 'gmr_picassa_url_icon' );
		$flickr_url      = get_theme_mod( 'gmr_flickr_url_icon' );
		$blogger_url     = get_theme_mod( 'gmr_blogger_url_icon' );
		$spotify_url     = get_theme_mod( 'gmr_spotify_url_icon' );
		$rssicon         = get_theme_mod( 'gmr_active-rssicon', 0 );

		$social = '';
		if ( $fb_url || $twitter_url || $pinterest_url || $tumblr_url || $stumbleupon_url || $wordpress_url || $instagram_url || $dribbble_url || $vimeo_url ||
		$linkedin_url || $deviantart_url || $skype_url || $youtube_url || $myspace_url || $picassa_url || $flickr_url || $blogger_url || $spotify_url || 0 === $rssicon ) :
			if ( 0 === $mod_social ) :
				$social .= '
					<li class="menu-item menu-item-type-custom menu-item-object-custom gmr-social-menu">
						<a href="#" title="' . __( 'Social Network', 'majalahpro' ) . '" rel="nofollow" class="gmr-social-mainlink" itemprop="url">
							<span class="social_facebook"></span>
							<span class="social_twitter"></span>
							<span class="social_rss"></span>
						</a>';
				$social .= '<ul class="sub-menu">';
				if ( $fb_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $fb_url ) . '" title="' . esc_html__( 'Facebook', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_facebook"></span>' . esc_html__( 'Facebook', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $twitter_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $twitter_url ) . '" title="' . esc_html__( 'Twitter', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_twitter"></span>' . esc_html__( 'Twitter', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $pinterest_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $pinterest_url ) . '" title="' . esc_html__( 'Pinterest', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_pinterest"></span>' . esc_html__( 'Pinterest', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $tumblr_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $tumblr_url ) . '" title="' . esc_html__( 'Tumblr', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_tumblr"></span>' . esc_html__( 'Tumblr', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $stumbleupon_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $stumbleupon_url ) . '" title="' . esc_html__( 'Stumbleupon', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_tumbleupon"></span>' . esc_html__( 'Stumbleupon', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $wordpress_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $wordpress_url ) . '" title="' . esc_html__( 'WordPress', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_wordpress"></span>' . esc_html__( 'WordPress', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $instagram_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $instagram_url ) . '" title="' . esc_html__( 'Instagram', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_instagram"></span>' . esc_html__( 'Instagram', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $dribbble_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $dribbble_url ) . '" title="' . esc_html__( 'Dribbble', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_dribbble"></span>' . esc_html__( 'Dribbble', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $vimeo_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $vimeo_url ) . '" title="' . esc_html__( 'Vimeo', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_vimeo"></span>' . esc_html__( 'Vimeo', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $linkedin_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $linkedin_url ) . '" title="' . esc_html__( 'Linkedin', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_linkedin"></span>' . esc_html__( 'Linkedin', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $deviantart_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $deviantart_url ) . '" title="' . esc_html__( 'Deviantart', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_deviantart"></span>' . esc_html__( 'Deviantart', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $myspace_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $myspace_url ) . '" title="' . esc_html__( 'Myspace', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_myspace"></span>' . esc_html__( 'Myspace', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $skype_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $skype_url ) . '" title="' . esc_html__( 'Skype', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_skype"></span>' . esc_html__( 'Skype', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $youtube_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $youtube_url ) . '" title="' . esc_html__( 'Youtube', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_youtube"></span>' . esc_html__( 'Youtube', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $picassa_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $picassa_url ) . '" title="' . esc_html__( 'Picassa', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_picassa"></span>' . esc_html__( 'Picassa', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $flickr_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $flickr_url ) . '" title="' . esc_html__( 'Flickr', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_flickr"></span>' . esc_html__( 'Flickr', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $blogger_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $blogger_url ) . '" title="' . esc_html__( 'Blogger', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_blogger"></span>' . esc_html__( 'Blogger', 'majalahpro' ) . '</a></li>';
				endif;

				if ( $spotify_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $spotify_url ) . '" title="' . esc_html__( 'Spotify', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_spotify"></span>' . esc_html__( 'Spotify', 'majalahpro' ) . '</a></li>';
				endif;

				$delicious_url = get_theme_mod( 'gmr_delicious_url_icon' );
				if ( $delicious_url ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( $delicious_url ) . '" title="' . esc_html__( 'Delicious', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_delicious"></span>' . esc_html__( 'Delicious', 'majalahpro' ) . '</a></li>';
				endif;

				if ( 0 === $rssicon ) :
					$social .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-social-network"><a href="' . esc_url( get_bloginfo( 'rss2_url' ) ) . '" title="' . esc_html__( 'RSS', 'majalahpro' ) . '" target="_blank" rel="nofollow"><span class="social_rss"></span>' . esc_html__( 'RSS', 'majalahpro' ) . '</a></li>';
				endif;

				$social .= '</ul>';

				$social .= '</li>';
			endif;
		endif;

		// search.
		// Option remove search button.
		$setting    = 'gmr_active-searchbutton';
		$mod_search = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$search = '';
		if ( 0 === $mod_search ) :
			$css_class = 'menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children gmr-search';

			$search .= '<li class="' . esc_attr( $css_class ) . '">';
			$search .= '<a href="#" title="' . __( 'Search', 'majalahpro' ) . '" rel="nofollow" itemprop="url"><span class="icon_search"></span><span itemprop="name">' . __( 'Search', 'majalahpro' ) . '</span></a>';
			$search .= '<ul class="sub-menu-search">';
			$search .= '<li id="menu-item-search" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-search">';
			$search .= '<form method="get" class="gmr-searchform searchform" action="' . esc_url( home_url( '/' ) ) . '">';
			$search .= '<input type="text" name="s" id="s" placeholder="' . __( 'Search', 'majalahpro' ) . '" />';
			$search .= '</form>';
			$search .= '</li>';
			$search .= '</ul>';
			$search .= '</li>';

		endif;

		// Date.
		// Option remove date.
		$setting  = 'gmr_active-date';
		$mod_date = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$date = '';
		if ( 0 === $mod_date ) :
			$date .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-object-date"><span class="gmr-top-date">' . date_i18n( get_option( 'date_format' ) ) . '</span></li>';
		endif;

		// Primary Navigation Area Only.
		if ( ( isset( $ajax ) && $ajax ) || ( property_exists( $args, 'theme_location' ) && 'topnav' === $args->theme_location ) ) {
			return $date . $search . $items . $social;

		}
		return apply_filters( 'gmr_nav_wrap_filter', $items );
	}
endif; // endif gmr_nav_wrap.
add_filter( 'wp_nav_menu_items', 'gmr_nav_wrap', 15, 2 );

if ( ! function_exists( 'majalahpro_add_menu_attribute' ) ) :
	/**
	 * Add attribute itemprop="url" to menu link
	 *
	 * @since 1.0.0
	 *
	 * @param string $atts Atts.
	 * @param string $item Item.
	 * @param array  $args Args.
	 * @return string
	 */
	function majalahpro_add_menu_attribute( $atts, $item, $args ) {
		$atts['itemprop'] = 'url';
		return $atts;
	}
endif; // endif majalahpro_add_menu_attribute.
add_filter( 'nav_menu_link_attributes', 'majalahpro_add_menu_attribute', 10, 3 );

if ( ! function_exists( 'majalahpro_add_link_adminmenu' ) ) :
	/**
	 * Add default menu for fallback top menu
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function majalahpro_add_link_adminmenu() {
		echo '<ul id="primary-menu">';
			echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" style="border: none !important;">' . esc_html__( 'Add a Menu', 'majalahpro' ) . '</a></li>';
		echo '</ul>';
	}
endif; // endif majalahpro_add_link_adminmenu.

if ( ! function_exists( 'gmr_the_custom_logo' ) ) :
	/**
	 * Print custom logo.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_the_custom_logo() {
		echo '<div class="gmr-logo">';
		// if get value from customizer gmr_logoimage.
		$setting = 'gmr_logoimage';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		if ( $mod ) {
			// get url image from value gmr_logoimage.
			$image = esc_url_raw( $mod );
			echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="custom-logo-link" ' . majalahpro_itemprop_schema( 'url' ) . ' title="' . esc_html( get_bloginfo( 'name' ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<img src="' . esc_url( $image ) . '" alt="' . esc_html( get_bloginfo( 'name' ) ) . '" title="' . esc_html( get_bloginfo( 'name' ) ) . '" />';
			echo '</a>';

		} else {
			// if get value from customizer blogname.
			if ( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) ) {
				echo '<div class="site-title" ' . majalahpro_itemprop_schema( 'headline' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<a href="' . esc_url( home_url( '/' ) ) . '" ' . majalahpro_itemprop_schema( 'url' ) . ' title="' . esc_html( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( get_theme_mod( 'blogname', get_bloginfo( 'name' ) ) );
					echo '</a>';
				echo '</div>';

			}
			// if get value from customizer blogdescription.
			if ( get_theme_mod( 'blogdescription', get_bloginfo( 'description' ) ) ) {
				echo '<span class="site-description" ' . majalahpro_itemprop_schema( 'description' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( get_theme_mod( 'blogdescription', get_bloginfo( 'description' ) ) );
				echo '</span>';

			}
		}
		echo '</div>';
	}
endif; // endif gmr_the_custom_logo.
add_action( 'gmr_the_custom_logo', 'gmr_the_custom_logo', 5 );

if ( ! function_exists( 'gmr_move_post_navigation' ) ) :
	/**
	 * Move post navigation in top after content.
	 *
	 * @param String $content Content.
	 * @since 1.0.0
	 *
	 * @return string $content
	 */
	function gmr_move_post_navigation( $content ) {
		if ( is_singular() && in_the_loop() ) {
			$pagination = wp_link_pages(
				array(
					'before'      => '<div class="page-links clearfix"><span class="page-text">' . esc_html__( 'Pages:', 'majalahpro' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span class="page-link-number">',
					'link_after'  => '</span>',
					'echo'        => 0,
				)
			);
			$content   .= $pagination;
			return $content;
		}
		return $content;
	}
endif; // endif gmr_move_post_navigation.
add_filter( 'the_content', 'gmr_move_post_navigation', 35 );

if ( ! function_exists( 'gmr_move_post_navigation_second' ) ) :
	/**
	 * Move post navigation in top after content.
	 *
	 * @param String $content Content.
	 * @since 1.0.0
	 *
	 * @return string $content
	 */
	function gmr_move_post_navigation_second( $content ) {
		if ( is_singular() && in_the_loop() ) {
			$pagination_nextprev = wp_link_pages(
				array(
					'before'         => '<div class="prevnextpost-links clearfix">',
					'after'          => '</div>',
					'next_or_number' => 'next',
					'link_before'    => '<span class="prevnextpost">',
					'link_after'     => '</span>',
					'echo'           => 0,
				)
			);

			$content .= $pagination_nextprev;
			return $content;
		}
		return $content;
	}
endif; // endif gmr_move_post_navigation_second.
add_filter( 'the_content', 'gmr_move_post_navigation_second', 2 );

if ( ! function_exists( 'gmr_embed_oembed_html' ) ) :
	/**
	 * Add responsive oembed class.
	 *
	 * @param String $html Content.
	 * @param String $url URL.
	 * @param String $attr Attribute.
	 * @param Number $post_id ID Post.
	 * @add_filter embed_oembed_html
	 * @class ktz-videowrapper
	 * @link https://developer.wordpress.org/reference/hooks/embed_oembed_html/
	 */
	function gmr_embed_oembed_html( $html, $url, $attr, $post_id ) {
		$classes = array();

		// Add these classes to all embeds.
		$classes_all = array(
			'gmr-video-responsive',
		);

		// Check for different providers and add appropriate classes.
		if ( false !== strpos( $url, 'vimeo.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtube.com' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		if ( false !== strpos( $url, 'youtu.be' ) ) {
			$classes[] = 'gmr-embed-responsive gmr-embed-responsive-16by9';
		}

		$classes = array_merge( $classes, $classes_all );

		return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . $html . '</div>';
	}
endif; // endif gmr_embed_oembed_html.
add_filter( 'embed_oembed_html', 'gmr_embed_oembed_html', 99, 4 );

if ( ! function_exists( 'majalahpro_prepend_attachment' ) ) :
	/**
	 * Callback for WordPress 'prepend_attachment' filter.
	 *
	 * Change the attachment page image size to 'large'
	 *
	 * @package WordPress
	 * @category Attachment
	 * @see wp-includes/post-template.php
	 *
	 * @param string $attachment_content the attachment html.
	 * @return string $attachment_content the attachment html
	 */
	function majalahpro_prepend_attachment( $attachment_content ) {
		$post = get_post();
		if ( wp_attachment_is( 'image', $post ) ) {
			// set the attachment image size to 'large'.
			$attachment_content = sprintf( '<p class="img-center">%s</p>', wp_get_attachment_link( 0, 'full', false ) );

			// return the attachment content.
			return $attachment_content;
		} else {
			// return the attachment content.
			return $attachment_content;
		}
	}
endif; // endif majalahpro_prepend_attachment.
add_filter( 'prepend_attachment', 'majalahpro_prepend_attachment' );

if ( ! function_exists( 'majalahpro_share_default' ) ) :
	/**
	 * Insert social share
	 *
	 * @since 1.0.0
	 * @param string $output Default is null.
	 * @return string @output
	 */
	function majalahpro_share_default( $output = null ) {
		global $post;

		$filter_title = str_replace( ' ', '%20', get_the_title() );

		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
		if ( ! empty( $image ) ) {
			$thumb = $image[0];
		} else {
			// If function exist.
			if ( function_exists( 'majalahpro_core_get_images_only' ) ) {
				$thumb = majalahpro_core_get_images_only( 'full', false );
			} else {
				$thumb = '';
			}
		}

		$output  = '';
		$output .= '<div class="gmr-social-share">';
		$output .= '<ul class="gmr-socialicon-share">';
		$output .= '<li class="facebook">';
		$output .= '<a href="https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( esc_url( get_permalink() ) ) . '" class="gmr-share-facebook" rel="nofollow" title="' . __( 'Share this', 'majalahpro' ) . '">';
		$output .= '<span class="social_facebook"></span>';
		$output .= '</a>';
		$output .= '</li>';
		$output .= '<li class="twitter">';
		$output .= '<a href="https://twitter.com/share?url=' . rawurlencode( esc_url( get_permalink() ) ) . '&amp;text=' . $filter_title . '" class="gmr-share-twitter" rel="nofollow" title="' . __( 'Tweet this', 'majalahpro' ) . '">';
		$output .= '<span class="social_twitter"></span>';
		$output .= '</a>';
		$output .= '</li>';
		$output .= '<li class="pinterest">';
		$output .= '<a href="https://pinterest.com/pin/create/button/?url=' . rawurlencode( esc_url( get_permalink() ) ) . '&amp;media=' . $thumb . '&amp;description=' . $filter_title . '" class="gmr-share-pinit" rel="nofollow" title="' . __( 'Pin this', 'majalahpro' ) . '">';
		$output .= '<span class="social_pinterest"></span>';
		$output .= '</a>';
		$output .= '</li>';
		$output .= '<li class="whatsapp">';
		$output .= '<a href="https://api.whatsapp.com/send?text=' . $filter_title . '%20' . rawurlencode( esc_url( get_permalink() ) ) . '" class="gmr-share-whatsapp" rel="nofollow" title="' . __( 'Whatsapp', 'newkarma' ) . '">';
		$output .= '<img src="' . get_template_directory_uri() . '/images/whatsapp.png" alt="' . __( 'Whatsapp', 'newkarma' ) . '" title="' . __( 'Whatsapp', 'newkarma' ) . '" />';
		$output .= '</a>';
		$output .= '</li>';
		$output .= '</ul>';
		$output .= '</div>';

		return $output;

	}
endif; // endif majalahpro_share_default.

if ( ! function_exists( 'majalahpro_add_share_in_single' ) ) :
	/**
	 * Insert social share in single
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function majalahpro_add_share_in_single() {
		if ( is_single() && in_the_loop() ) {
			echo majalahpro_share_default(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
endif; // endif majalahpro_add_share_in_single.
add_action( 'majalahpro_add_share_in_single', 'majalahpro_add_share_in_single', 40 );
