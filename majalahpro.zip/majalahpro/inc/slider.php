<?php
/**
 * Custom homepage category content.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'ajax_add_slide_content' ) ) :
	/**
	 * Main ajax action function
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function ajax_add_slide_content() {
		$tab  = $_POST['tab']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$args = $_POST['args']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		// json_encode() failed.
		if ( ! is_array( $args ) || empty( $args ) ) {
			die( esc_html__( 'Unable to load content', 'majalahpro' ) );
		}

		$post_num = ( empty( $args['post_num'] ) ? 5 : intval( $args['post_num'] ) );

		$cat   = ( empty( $args['cat'] ) ? 0 : intval( $args['cat'] ) );
		$cat_2 = ( empty( $args['cat_2'] ) ? 0 : intval( $args['cat_2'] ) );
		$cat_3 = ( empty( $args['cat_3'] ) ? 0 : intval( $args['cat_3'] ) );
		$cat_4 = ( empty( $args['cat_4'] ) ? 0 : intval( $args['cat_4'] ) );
		$cat_5 = ( empty( $args['cat_5'] ) ? 0 : intval( $args['cat_5'] ) );

		switch ( $tab ) {
			case '1':
				// standard params.
				$query_args                   = array(
					'no_found_rows'          => true,
					'post_status'            => 'publish',
					// make it fast withour update term cache and cache results
					// https://thomasgriffin.io/optimize-wordpress-queries/.
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'cache_results'          => false,
					'ignore_sticky_posts'    => 1,
				);
				$query_args['posts_per_page'] = 2;
				$query_args['cat']            = $cat;

				// run the query: get the latest posts.
				$recent = new WP_Query( apply_filters( 'majalahpro_slide_posts_args', $query_args ) );

				if ( $recent->have_posts() ) {
					echo '<div class="gmr-module-slide-topic"><a href="' . esc_url( get_category_link( $cat ) ) . '" title="' . esc_html( get_cat_name( $cat ) ) . '">' . esc_html( get_cat_name( $cat ) ) . '</a></div>';

					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<div class="ajax-content-module">
							<?php
							$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

							if ( ! empty( $featured_image_url ) ) {
								?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
									<?php
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'medium' );
									endif;
									?>
								</a>

							<?php } ?>
							<div class="gmr-module-slide-title">
								<a href="<?php the_permalink(); ?>" class="gmr-module-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php
							$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);

							$posted_on = $time_string;
							echo '<div class="gmr-metacontent"><span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<?php
					endwhile;
					wp_reset_postdata();
				}
				break;

			case '2':
				// standard params.
				$query_args = array(
					'no_found_rows'          => true,
					'post_status'            => 'publish',
					// make it fast withour update term cache and cache results.
					// https://thomasgriffin.io/optimize-wordpress-queries/.
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'cache_results'          => false,
					'ignore_sticky_posts'    => 1,
				);

				$query_args['posts_per_page'] = 2;
				$query_args['cat']            = $cat_2;

				// run the query: get the latest posts.
				$recent = new WP_Query( apply_filters( 'majalahpro_slide_posts_args_2', $query_args ) );

				if ( $recent->have_posts() ) {
					echo '<div class="gmr-module-slide-topic"><a href="' . esc_url( get_category_link( $cat_2 ) ) . '" title="' . esc_html( get_cat_name( $cat_2 ) ) . '">' . esc_html( get_cat_name( $cat_2 ) ) . '</a></div>';
					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<div class="ajax-content-module">
							<?php
							$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

							if ( ! empty( $featured_image_url ) ) {
								?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
									<?php
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'medium' );
									endif;
									?>
								</a>
							<?php } ?>
							<div class="gmr-module-slide-title">
								<a href="<?php the_permalink(); ?>" class="gmr-module-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php
							$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}
							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);
							$posted_on   = $time_string;
							echo '<div class="gmr-metacontent"><span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<?php
					endwhile;
					wp_reset_postdata();
				}
				break;

			case '3' :
				// standard params.
				$query_args = array(
					'no_found_rows'          => true,
					'post_status'            => 'publish',
					// make it fast withour update term cache and cache results.
					// https://thomasgriffin.io/optimize-wordpress-queries/.
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'cache_results'          => false,
					'ignore_sticky_posts'    => 1,
				);

				$query_args['posts_per_page'] = 2;
				$query_args['cat']            = $cat_3;

				// run the query: get the latest posts.
				$recent = new WP_Query( apply_filters( 'majalahpro_slide_posts_args_3', $query_args ) );

				if ( $recent->have_posts() ) {
					echo '<div class="gmr-module-slide-topic"><a href="' . esc_url( get_category_link( $cat_3 ) ) . '" title="' . esc_html( get_cat_name( $cat_3 ) ) . '">' . esc_html( get_cat_name( $cat_3 ) ) . '</a></div>';
					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<div class="ajax-content-module">
							<?php
							$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
							if ( ! empty( $featured_image_url ) ) {
								?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
									<?php
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'medium' );
									endif;
									?>
								</a>
							<?php } ?>
							<div class="gmr-module-slide-title">
								<a href="<?php the_permalink(); ?>" class="gmr-module-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php
							$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}
							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);
							$posted_on   = $time_string;
							echo '<div class="gmr-metacontent"><span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<?php

					endwhile;
					wp_reset_postdata();
				}
				break;

			case '4':
				// standard params.
				$query_args = array(
					'no_found_rows'          => true,
					'post_status'            => 'publish',
					// make it fast withour update term cache and cache results.
					// https://thomasgriffin.io/optimize-wordpress-queries/.
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'cache_results'          => false,
					'ignore_sticky_posts'    => 1,
				);

				$query_args['posts_per_page'] = 2;
				$query_args['cat']            = $cat_4;

				// run the query: get the latest posts.
				$recent = new WP_Query( apply_filters( 'majalahpro_slide_posts_args_4', $query_args ) );

				if ( $recent->have_posts() ) {
						echo '<div class="gmr-module-slide-topic"><a href="' . esc_url( get_category_link( $cat_4 ) ) . '" title="' . esc_html( get_cat_name( $cat_4 ) ) . '">' . esc_html( get_cat_name( $cat_4 ) ) . '</a></div>';
					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<div class="ajax-content-module">
							<?php
							$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

							if ( ! empty( $featured_image_url ) ) {
								?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
									<?php
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'medium' );
									endif;
									?>
								</a>

							<?php } ?>
							<div class="gmr-module-slide-title">
								<a href="<?php the_permalink(); ?>" class="gmr-module-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php
							$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}
							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);
							$posted_on   = $time_string;
							echo '<div class="gmr-metacontent"><span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<?php

					endwhile;
					wp_reset_postdata();
				}
				break;

			case '5':
				// standard params.
				$query_args = array(
					'no_found_rows'          => true,
					'post_status'            => 'publish',
					// make it fast withour update term cache and cache results.
					// https://thomasgriffin.io/optimize-wordpress-queries/.
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'cache_results'          => false,
					'ignore_sticky_posts'    => 1,
				);

				$query_args['posts_per_page'] = 2;
				$query_args['cat']            = $cat_5;

				// run the query: get the latest posts.
				$recent = new WP_Query( apply_filters( 'majalahpro_slide_posts_args_5', $query_args ) );

				if ( $recent->have_posts() ) {
					echo '<div class="gmr-module-slide-topic"><a href="' . esc_url( get_category_link( $cat_5 ) ) . '" title="' . esc_html( get_cat_name( $cat_5 ) ) . '">' . esc_html( get_cat_name( $cat_5 ) ) . '</a></div>';
					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<div class="ajax-content-module">
							<?php
							$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
							if ( ! empty( $featured_image_url ) ) {
								?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
									<?php
									if ( has_post_thumbnail() ) :
										the_post_thumbnail( 'medium' );
									endif;
									?>
								</a>
							<?php } ?>
							<div class="gmr-module-slide-title">
								<a href="<?php the_permalink(); ?>" class="gmr-module-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</div>
							<?php
							$time_string = '<time class="entry-date published updated" ' . majalahpro_itemprop_schema( 'dateModified' ) . ' datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" ' . majalahpro_itemprop_schema( 'datePublished' ) . ' datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}
							$time_string = sprintf(
								$time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);
							$posted_on   = $time_string;
							echo '<div class="gmr-metacontent"><span class="posted-on"><span class="icon_clock_alt byline"></span>' . $posted_on . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<?php

					endwhile;
					wp_reset_postdata();
				}
				break;
		}
		die(); // required to return a proper result.
	}
endif;
add_action( 'wp_ajax_add_slide_content', 'ajax_add_slide_content' );
add_action( 'wp_ajax_nopriv_add_slide_content', 'ajax_add_slide_content' );

if ( ! function_exists( 'majalahpro_display_ajax_slide' ) ) :
	/**
	 * This function for display slider in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function majalahpro_display_ajax_slide() {
		global $post;
		$post_num = 5;
		$cat      = get_theme_mod( 'gmr_category-big-slide', 0 );

		$args = array(
			'post_type'           => 'post',
			'cat'                 => $cat,
			'orderby'             => 'date',
			'order'               => 'desc',
			'showposts'           => $post_num,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
		);

		$recent = get_posts( $args );

		echo '<div class="gmr-owl-carousel">';
		echo '<div id="gmr-slide-sync1" class="owl-carousel owl-theme owl-little">';
		foreach ( $recent as $post ) :
			setup_postdata( $post );

			$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

			if ( ! empty( $featured_image_url ) ) {
				?>
				<div class="item">
					<div class="gmr-slider-content">
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '', 'echo' => true ) ); ?>">
							<?php
							if ( has_post_thumbnail() ) :
								the_post_thumbnail( 'large' );
							endif;
							?>
						</a>

						<div class="gmr-slide-title">
							<?php
							if ( ! is_wp_error( get_the_term_list( $post->ID, 'newstopic' ) ) ) {
								$termlist = get_the_term_list( $post->ID, 'newstopic' );
								if ( ! empty( $termlist ) ) {
									echo '<div class="gmr-slide-topic">';
										echo get_the_term_list( $post->ID, 'newstopic', '', ', ', '' );
									echo '</div>';
								}
							}
							?>
							<a href="<?php the_permalink(); ?>" class="gmr-slide-titlelink" title="<?php the_title(); ?>"><?php the_title(); ?></a>
						</div>
					</div>
				</div>
			<?php } ?>
			<?php
		endforeach;
		echo '</div>';

		echo '<div id="gmr-slide-sync2" class="owl-carousel owl-theme owl-little">';
		foreach ( $recent as $post ) :
			setup_postdata( $post );
			$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
			if ( ! empty( $featured_image_url ) ) :
				echo '<div class="item">';
				the_post_thumbnail( 'medium' );
				$post_title = get_the_title();
				if ( mb_strlen( $post_title ) > 45 ) {
					// get post_title in desired length.
					$post_title = mb_substr( $post_title, 0, 45 );
					echo '<span class="ajax-tab-title">';
					echo esc_html( $post_title );
					echo '</span>';

				} else {
					echo '<span class="ajax-tab-title">';
					echo esc_html( get_the_title() );
					echo '</span>';

				}
				echo '</div>';
			endif;
		endforeach;
		echo '</div>';
		echo '</div>';
	}
endif; // endif majalahpro_display_ajax_slide.
add_action( 'majalahpro_display_ajax_slide', 'majalahpro_display_ajax_slide', 50 );

if ( ! function_exists( 'majalahpro_display_ajax_module' ) ) :
	/**
	 * This function for display slider in homepage via ajax.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function majalahpro_display_ajax_module() {
		$post_num = 5;

		$cat_1 = get_theme_mod( 'gmr_category-module-slide' );
		$cat_2 = get_theme_mod( 'gmr_category-module-slide-2' );
		$cat_3 = get_theme_mod( 'gmr_category-module-slide-3' );
		$cat_4 = get_theme_mod( 'gmr_category-module-slide-4' );
		$cat_5 = get_theme_mod( 'gmr_category-module-slide-5' );

		if ( ( ! empty( $cat_1 ) ) || ( ! empty( $cat_2 ) ) || ( ! empty( $cat_3 ) ) || ( ! empty( $cat_4 ) ) || ( ! empty( $cat_5 ) ) ) {
			echo '<div class="site-main">';
			echo '<div class="add_slide_content" id="gmr-ajax-module-slide-id">';

			echo '<ul class="module-slide-tabs gmr-ajax-tab clearfix" id="gmr-ajax-tab-id">';
			if ( ! empty( $cat_1 ) ) {
				echo '<li><a href="#" id="1-tab">&nbsp;</a></li>';
			}
			if ( ! empty( $cat_2 ) ) {
				echo '<li><a href="#" id="2-tab">&nbsp;</a></li>';
			}
			if ( ! empty( $cat_3 ) ) {
				echo '<li><a href="#" id="3-tab">&nbsp;</a></li>';
			}
			if ( ! empty( $cat_4 ) ) {
				echo '<li><a href="#" id="4-tab">&nbsp;</a></li>';
			}
			if ( ! empty( $cat_5 ) ) {
				echo '<li><a href="#" id="5-tab">&nbsp;</a></li>';
			}
			echo '</ul>';

			echo '<div class="inside-ajax-load gmr-box-content-module">';
			if ( ! empty( $cat_1 ) ) {
				echo '<div id="1-tab-content" class="tab-content"></div>';
			}
			if ( ! empty( $cat_2 ) ) {
				echo '<div id="2-tab-content" class="tab-content"></div>';
			}
			if ( ! empty( $cat_3 ) ) {
				echo '<div id="3-tab-content" class="tab-content"></div>';
			}
			if ( ! empty( $cat_4 ) ) {
				echo '<div id="4-tab-content" class="tab-content"></div>';
			}
			if ( ! empty( $cat_5 ) ) {
				echo '<div id="5-tab-content" class="tab-content"></div>';
			}
			echo '</div>';

			echo '</div>';
			echo '</div>';

			echo '<script type="text/javascript">';
				echo 'jQuery(function($) {';
					echo '$(\'#gmr-ajax-module-slide-id\').data(\'args\', {"post_num":"5", "cat":"' . esc_html( $cat_1 ) . '", "cat_2":"' . esc_html( $cat_2 ) . '", "cat_3":"' . esc_html( $cat_3 ) . '", "cat_4":"' . esc_html( $cat_4 ) . '", "cat_5":"' . esc_html( $cat_5 ) . '"});';
				echo '});';
			echo '</script>';

		}
	}
endif; // endif majalahpro_display_ajax_module.
add_action( 'majalahpro_display_ajax_module', 'majalahpro_display_ajax_module', 50 );
