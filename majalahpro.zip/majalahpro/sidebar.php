<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area col-md-sb-r" role="complementary" <?php majalahpro_itemtype_schema( 'WPSideBar' ); ?>>
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
	<div id="colophon" class="site-footer widget" role="contentinfo" <?php majalahpro_itemtype_schema( 'WPFooter' ); ?>>
		<?php
		$copyright = get_theme_mod( 'gmr_copyright' );
		if ( $copyright ) :
			// sanitize html output than convert it again using htmlspecialchars_decode.
			echo '<span class="pull-left theme-copyright">';
				echo esc_html( htmlspecialchars_decode( $copyright ) );
			echo '</span>';
		else :
			?>
			<a href="<?php echo esc_url( __( 'http://www.gianmr.com/', 'majalahpro' ) ); ?>" class="theme-copyright pull-left" title="<?php echo esc_html__( 'Theme: Majalahpro', 'majalahpro' ); ?>"><?php echo esc_html__( '&copy; Majalahpro', 'majalahpro' ); ?></a>
		<?php endif; ?>
		<?php
		// Second top menu.
		if ( has_nav_menu( 'copyrightnav' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'copyrightnav',
					'container'      => 'ul',
					'menu_id'        => 'copyright-menu',
					'depth'          => 1,
				)
			);
		}
		?>
	</div><!-- #colophon -->
</aside><!-- #secondary -->
