<?php
/**
 * The template for displaying category pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header( 'amp' );

?>

<div id="primary" class="content-area col-md-content">


		<main id="main" class="site-main gmr-infinite-selector" role="main">

		<?php
		if ( have_posts() ) {
			$count = 0;

			echo '<div id="gmr-main-load">';

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				$count++;

				if ( (int) get_query_var( 'paged' ) > 1 ) {
					$first_post = false;
				} else {
					$first_post = true;
				}

				if ( 1 === $count && $first_post ) {
					/*
					 * Include the Post-Format-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', 'first' );

				} else {

					/**
					 * Include the Post-Format-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', get_post_format() );

					do_action( 'majalahpro_core_banner_between_posts' );

				}

			endwhile;

			echo '</div>';

			echo gmr_get_pagination(); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */

		} else {
			get_template_part( 'template-parts/content', 'none' );

		}
		?>

		</main><!-- #main -->

</div><!-- #primary -->

<?php

get_footer( 'amp' );
