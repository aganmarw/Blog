<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Disable thumbnail options via customizer.
$thumbnail = get_theme_mod( 'gmr_active-singlethumb', 0 );

// Disable meta data options via customizer.
$metadata = get_theme_mod( 'gmr_active-metasingle', 0 );

// Disable Social Share via customizer.
$socialshare = get_theme_mod( 'gmr_active-socialshare', 0 );

// Disable post navigation options via customizer.
$postnav = get_theme_mod( 'gmr_active-prevnext-post', 0 );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> <?php echo majalahpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>

	<div class="gmr-box-content site-main gmr-single">
		<?php
		if ( ! is_wp_error( get_the_term_list( $post->ID, 'newstopic' ) ) ) {
			$termlist = get_the_term_list( $post->ID, 'newstopic' );
			if ( ! empty( $termlist ) ) {
				echo '<span class="gmr-meta-topic">';
				echo get_the_term_list( $post->ID, 'newstopic', '', ', ', '' );
				echo '</span>';
			}
		}
		?>
		<header class="entry-header">
			<?php the_title( '<h1 class="entry-title" ' . majalahpro_itemprop_schema( 'headline' ) . '>', '</h1>' ); ?>
			<?php
			if ( 0 === $metadata ) :
				gmr_posted_on();
			endif;
			?>

		</header><!-- .entry-header -->

		<?php
		echo '<div class="row">';
		echo '<div class="col-md-content">';


		// custom field using oembed https://codex.wordpress.org/Embeds.
		$majpro_oembed = get_post_meta( $post->ID, 'MAJPRO_Oembed', true );
		$majpro_iframe = get_post_meta( $post->ID, 'MAJPRO_Iframe', true );

		if ( ! empty( $majpro_oembed ) ) {
			echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9">';
			echo wp_oembed_get( $majpro_oembed ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
			echo '</div>';

		} elseif ( ! empty( $majpro_iframe ) ) {
			echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9">';
			echo do_shortcode( $majpro_iframe );
			echo '</div>';

		} else {
			// displaying gallery.
			do_action( 'majalahpro_display_attachment_gallery' );

			// displaying thumbnail.
			if ( 0 === $thumbnail ) :
				if ( has_post_thumbnail() ) {
					?>
					<figure class="wp-caption alignnone gmr-single-image">
						<?php the_post_thumbnail(); ?>
						<?php
						if ( $caption = get_post( get_post_thumbnail_id() )->post_excerpt ) :
							?>
							<figcaption class="wp-caption-text"><?php echo esc_html( $caption ); ?></figcaption>
						<?php endif; ?>
					</figure>
					<?php
				}
			endif;
		}

		?>

			<div class="entry-content entry-content-single" <?php echo majalahpro_itemprop_schema( 'text' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
				<?php
					the_content();
				?>
			</div><!-- .entry-content -->

			<footer class="entry-footer">
				<?php
				gmr_entry_footer();

				// Add first related post.
				do_action( 'majalahpro_core_add_related_the_content' );

				if ( 0 === $metadata ) :
					// Add author meta.
					do_action( 'gmr_posted_on_author_single' );
				endif;
				
				$majpro_editorname = get_post_meta( $post->ID, 'MAJPRO_Editorname', true );
				if ( ! empty( $majpro_editorname ) ) {
					echo '<div class="gmr-metacontent-source">';
					echo esc_html__( 'Editor: ', 'majalahpro' ) . esc_attr( $majpro_editorname );
					echo '</div>';
				}

				$majpro_source = get_post_meta( $post->ID, 'MAJPRO_Source', true );

				if ( ! empty( $majpro_source ) ) {
					echo '<div class="gmr-metacontent-source">';
					echo esc_html__( 'Source: ', 'majalahpro' ) . '<a href="' . esc_url( $majpro_source ) . '" target="_blank" rel="nofollow">' . esc_url( $majpro_source ) . '</a>';
					echo '</div>';

				}

				// Add social icon in footer.
				do_action( 'gmr_footer_social' );

				if ( is_singular( 'post' ) ) {
					if ( 0 === $postnav ) :
						the_post_navigation(
							array(
								'prev_text' => __( '<span>Previous post</span> %title', 'majalahpro' ),
								'next_text' => __( '<span>Next post</span> %title', 'majalahpro' ),
							)
						);
					endif;
				}
				?>
			</footer><!-- .entry-footer -->

			<?php

			echo '</div>';
			if ( 0 === $socialshare ) :
				echo '<div class="col-md-content">';
					do_action( 'majalahpro_add_share_in_single' );
				echo '</div>';
			endif;
			echo '</div>';
			?>

	</div><!-- .gmr-box-content -->

	<?php do_action( 'majalahpro_core_author_box' ); ?>

	<?php do_action( 'majalahpro_core_add_second_related_the_content' ); ?>
	
	<?php
		if ( comments_open() || get_comments_number() ) :
			/* Add Non AMP Version using <div id="site-version-switcher"> and id="version-switch-link" */
			$nonamp_link = amp_remove_endpoint( amp_get_current_url() );
			echo '<div class="site-main gmr-box-content text-center"><div id="site-version-switcher"><a id="version-switch-link" class="button" href="' . esc_url( $nonamp_link ) . '#comments" class="amp-wp-canonical-link" title="' . __( 'Add Comment', 'majalahpro' ) . '" rel="noamphtml nofollow">' . __( 'Add Comment', 'majalahpro' ) . '</a></div></div>';
		endif;
	?>

</article><!-- #post-## -->
