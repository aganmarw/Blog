<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

			</div><!-- .row -->
		</div><!-- .container -->
		<div id="stop-container"></div>
	</div><!-- .gmr-content -->
</div><!-- #site-container -->


<?php
$mod = get_theme_mod( 'gmr_footer_column', '3col' );
if ( '4col' === $mod ) {
	$class = 'col-md-footer3';
} elseif ( '3col' === $mod ) {
	$class = 'col-md-footer4';
} elseif ( '2col' === $mod ) {
	$class = 'col-md-footer6';
} else {
	$class = 'col-md-main';
}

if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) ) :
	?>
	<div id="footer-container">
		<div id="footer-sidebar" class="widget-footer" role="complementary">
			<div class="container">
				<div class="row">
					<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
						<div class="footer-column <?php echo esc_html( $class ); ?>">
							<?php dynamic_sidebar( 'footer-1' ); ?>
						</div>
					<?php endif; ?>
					<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
						<div class="footer-column <?php echo esc_html( $class ); ?>">
							<?php dynamic_sidebar( 'footer-2' ); ?>
						</div>
					<?php endif; ?>
					<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
						<div class="footer-column <?php echo esc_html( $class ); ?>">
							<?php dynamic_sidebar( 'footer-3' ); ?>
						</div>
					<?php endif; ?>
					<?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
						<div class="footer-column <?php echo esc_html( $class ); ?>">
							<?php dynamic_sidebar( 'footer-4' ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div><!-- #footer-container -->
<?php endif; ?>

<?php do_action( 'majalahpro_core_floating_footer' ); ?>

<div class="gmr-ontop gmr-hide"><span class="arrow_up_alt"></span></div>

<?php wp_footer(); ?>

</body>
</html>
