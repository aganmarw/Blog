<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Majalahpro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Disable thumbnail options via customizer.
$thumbnail = get_theme_mod( 'gmr_active-blogthumb', 0 );

// Disable excerpt options via customizer.
$excerpt_opsi = get_theme_mod( 'gmr_active-excerptarchive', 0 );

// Blog Content options via customizer.
$blog_content = get_theme_mod( 'gmr_blog_content', 'excerpt' );

$classes = array(
	'clearfix',
	'item-infinite',
);

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?> <?php echo majalahpro_itemtype_schema( 'CreativeWork' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
	<div class="gmr-firstbox-content gmr-archive clearfix">

		<?php
		// Add thumnail.
		if ( 0 === $thumbnail ) :
			$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
			if ( ! empty( $featured_image_url ) ) :
					echo '<div class="firstcontent-thumbnail">';
						echo '<a href="' . esc_url( get_permalink() ) . '" itemprop="url" title="' .
						the_title_attribute(
							array(
								'before' => __( 'Permalink to: ', 'majalahpro' ),
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">';
							the_post_thumbnail( 'large' );
						echo '</a>';
					echo '</div>';

			endif;
		endif;
		?>

			<div class="gmr-firstcontent-title">
				<h2 class="entry-title" <?php echo majalahpro_itemprop_schema( 'headline' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>>
					<a href="<?php the_permalink(); ?>" <?php echo majalahpro_itemprop_schema( 'url' ); /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?> title="<?php the_title_attribute( array( 'before' => __( 'Permalink to: ', 'majalahpro' ), 'after' => '' ) ); ?>" rel="bookmark"><?php the_title(); ?></a>
				</h2>

			</div><!-- .entry-header -->

			<div class="entry-meta screen-reader-text">
				<?php gmr_posted_on(); ?>
			</div><!-- .entry-meta -->
	<?php if ( is_sticky() ) { ?>
		<kbd class="kbd-sticky"><?php esc_html_e( 'Sticky', 'majalahpro' ); ?></kbd>
	<?php } ?>

	<?php
		echo '<h1 class="firstpage-title" ' . majalahpro_itemprop_schema( 'headline' ) /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ . '><span>';
			$single_title = single_cat_title( '', false );
			echo esc_html( $single_title );
		echo '</span></h1>';
	?>

	</div><!-- .gmr-box-content -->

</article><!-- #post-## -->
