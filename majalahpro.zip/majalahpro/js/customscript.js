/**
 * Copyright (c) 2016 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package Majalahpro
 */

var $ = jQuery.noConflict();

(function( $ ) {
	/* http://www.w3schools.com/js/js_strict.asp */
	"use strict";

	$( document ).ready(
		function () {
			$( '#gmr-topnavresponsive-menu' ).sidr(
				{
					name: 'topnavmenus',
					source: '.gmr-mobilelogo, .close-topnavmenu-wrap, .gmr-mainmenu, .gmr-secondmenu, .gmr-topnavmenu',
					displace: false,
					onOpen   : function( name ) {
						// Re-name font Icons to correct classnames and support menu icon plugins.
						$( "#topnavmenus [class*='sidr-class-icon_'], #topnavmenus [class*='sidr-class-_mi']" ).attr( 'class',
							function( i, c ) {
								c = c.replace(/sidr-class-/g, '');
							return c;
						} );
					}
				}
			);
			$( '#sidr-id-close-topnavmenu-button' ).click(
				function(e){
					e.preventDefault();
					$.sidr( 'close', 'topnavmenus' );
				}
			);
			$( 'input#sidr-id-s' ).click(
				function(e){
					e.preventDefault();
					e.stopPropagation();
				}
			);
			$( '.sidr-inner li' ).each(
				function(index) {
					var item = $( this );
					if (item.find( 'ul' ).length > 0) {
						// Has submenus.
						item.find( 'a' ).first().append( '<span class="sub-toggle"><span class="arrow_carrot-down"></span></span>' );
					}
				}
			);
			$( '.sidr-inner .sub-toggle' ).click(
				function(e) {
					e.preventDefault();
					var item = $( this ),
					txt;
					item.toggleClass( 'is-open' );
					txt = item.hasClass( 'is-open' ) ? '<span class="arrow_carrot-up"></span>' : '<span class="arrow_carrot-down"></span>';
					item.html( txt );
					$( this ).closest( 'li' ).find( 'a' ).first().next().slideToggle();
				}
			);
		}
	); /* End document Ready */

	/* Sticky Menu */
	jQuery(
		function($) {
			$( window ).scroll(
				function() {
					if ( $( this ).scrollTop() > 400 ) {
						$( '.top-header' ).addClass( 'sticky-menu' );
					} else {
						$( '.top-header' ).removeClass( 'sticky-menu' );
					}
					if ( $( this ).scrollTop() > 5 ) {
						$( '.top-header-second' ).addClass( 'sticky-menu' );
					} else {
						$( '.top-header-second' ).removeClass( 'sticky-menu' );
					}
				}
			);
		}
	); /* End jQuery(function($) { */

	/* Accessibility Drop Down Menu */
	jQuery(
		function($) {
			$( '.menu-item-has-children a' ).focus(
				function () {
					$( this ).siblings( '.sub-menu' ).addClass( 'focused' );
				}
			).blur(
				function(){
					$( this ).siblings( '.sub-menu' ).removeClass( 'focused' );
				}
			);
			// Sub Menu.
			$( '.sub-menu a' ).focus(
				function () {
					$( this ).parents( '.sub-menu' ).addClass( 'focused' );
				}
			).blur(
				function(){
					$( this ).parents( '.sub-menu' ).removeClass( 'focused' );
				}
			);
		}
	); /* End jQuery(function($) { */

	/* Scroll to top */
	jQuery(
		function($) {
			var ontop = function(){
				var st = $( window ).scrollTop();
				if ( st < $( window ).height() ) {
					$( '.gmr-ontop' ).hide();
				} else {
					$( '.gmr-ontop' ).show();
				}
			}
			$( window ).scroll( ontop );
			$( '.gmr-ontop' ).click(
				function(){
					$( 'html, body' ).animate( {scrollTop:0}, 'normal' );
					return false;
				}
			);
		}
	); /* End jQuery(function($) { */

})( jQuery );

/**
 * File skip-link-focus-fix.js.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://git.io/vWdr2
 */
(function() {
	var isIe = /(trident|msie)/i.test( navigator.userAgent );

	if ( isIe && document.getElementById && window.addEventListener ) {
		window.addEventListener(
			'hashchange',
			function() {
				var id = location.hash.substring( 1 ),
					element;

				if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
					return;
				}

				element = document.getElementById( id );

				if ( element ) {
					if ( ! ( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
						element.tabIndex = -1;
					}

					element.focus();
				}
			},
			false
		);
	}
})();
