/**
 * Copyright (c) 2016 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package Majalahpro
 */

var $ = jQuery.noConflict();

(function( $ ) {
	/* http://www.w3schools.com/js/js_strict.asp */
	"use strict";

	$( document ).ready(
		function () {
			var sync1 = $( "#gmr-slide-sync1" );
			var sync2 = $( "#gmr-slide-sync2" );
			sync1.owlCarousel(
				{
					singleItem : true,
					slideSpeed : 1000,
					pagination:false,
					autoPlay: true,
					autoHeight:true,
					afterAction : syncPosition,
					responsiveRefreshRate : 200,
				}
			);

			sync2.owlCarousel(
				{
					items : 5,
					pagination:false,
					autoHeight:true,
					itemsDesktop : [1000,5], // 5 items between 1000px and 901px.
					itemsDesktopSmall : [900,5], // betweem 900px and 601px.
					itemsTablet: [600,5], // 2 items between 600 and 421.
					itemsMobile : [420,5],
					afterInit : function(el){
						el.find( ".owl-item" ).eq( 0 ).addClass( "synced" );
					}
				}
			);

			function syncPosition(el){
				var current = this.currentItem;
				$( "#gmr-slide-sync2" )
				.find( ".owl-item" )
				.removeClass( "synced" )
				.eq( current )
				.addClass( "synced" )
				if ( $( "#gmr-slide-sync2" ).data( "owlCarousel" ) !== undefined ) {
					center( current )
				}
			}

			$( "#gmr-slide-sync2" ).on(
				"click",
				".owl-item",
				function(e){
					e.preventDefault();
					var number = $( this ).data( "owlItem" );
					sync1.trigger( "owl.goTo",number );
				}
			);

			function center(number){
				var sync2visible = sync2.data( "owlCarousel" ).owl.visibleItems;

				var num = number;

				var found = false;

				for ( var i in sync2visible ) {
					if ( num === sync2visible[i] ) {
						var found = true;
					}
				}

				if ( found === false ) {
					if ( num > sync2visible[ sync2visible.length - 1 ] ) {
						sync2.trigger( "owl.goTo", num - sync2visible.length + 2 )
					} else {
						if ( num - 1 === -1 ) {
							num = 0;
						}
						sync2.trigger( "owl.goTo", num );
					}
				} else if ( num === sync2visible[ sync2visible.length - 1 ] ) {
					sync2.trigger( "owl.goTo", sync2visible[1] )
				} else if ( num === sync2visible[0] ) {
					sync2.trigger( "owl.goTo", num - 1 )
				}
			}
		}
	); /* End document Ready */

})( jQuery );
